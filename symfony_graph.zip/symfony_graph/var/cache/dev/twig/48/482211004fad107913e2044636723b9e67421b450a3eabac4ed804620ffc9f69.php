<?php

/* base.html.twig */
class __TwigTemplate_42a4a1dc6b6ff71d8d79cf6382ba36fc18b265bfb50fe94e70c9087c6dab2dc6 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_333ac2815786274583123aa5c355dc34ac4482cd0c6a818bda89d78b30639316 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_333ac2815786274583123aa5c355dc34ac4482cd0c6a818bda89d78b30639316->enter($__internal_333ac2815786274583123aa5c355dc34ac4482cd0c6a818bda89d78b30639316_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_a7f3e8ac6018550f8f078963fd38f28148f7d644293f0cc6cf1d475eca198101 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a7f3e8ac6018550f8f078963fd38f28148f7d644293f0cc6cf1d475eca198101->enter($__internal_a7f3e8ac6018550f8f078963fd38f28148f7d644293f0cc6cf1d475eca198101_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"../../favicon.ico\">
    ";
        // line 9
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "    <title>Starter Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href=\"https://v4-alpha.getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\">

    <!-- Custom styles for this template -->
    <link href=\"https://v4-alpha.getbootstrap.com/examples/starter-template/starter-template.css\" rel=\"stylesheet\">
  </head>

  <body>

    <nav class=\"navbar navbar-toggleable-md navbar-inverse bg-inverse fixed-top\">
      <button class=\"navbar-toggler navbar-toggler-right\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarsExampleDefault\" aria-controls=\"navbarsExampleDefault\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
        <span class=\"navbar-toggler-icon\"></span>
      </button>
      <a class=\"navbar-brand\" href=\"#\">Navbar</a>
    </nav>

    <div class=\"container\">
        ";
        // line 29
        $this->displayBlock('body', $context, $blocks);
        // line 30
        echo "    </div><!-- /.container -->

    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src=\"https://code.jquery.com/jquery-3.1.1.slim.min.js\" integrity=\"sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n\" crossorigin=\"anonymous\"></script>
    <script>window.jQuery || document.write('<script src=\"../../assets/js/vendor/jquery.min.js\"><\\/script>')</script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js\" integrity=\"sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb\" crossorigin=\"anonymous\"></script>
    <script src=\"https://v4-alpha.getbootstrap.com/dist/js/bootstrap.min.js\"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src=\"https://v4-alpha.getbootstrap.com/assets/js/ie10-viewport-bug-workaround.js\"></script>
    ";
        // line 42
        $this->displayBlock('javascripts', $context, $blocks);
        // line 43
        echo "  </body>
</html>

";
        
        $__internal_333ac2815786274583123aa5c355dc34ac4482cd0c6a818bda89d78b30639316->leave($__internal_333ac2815786274583123aa5c355dc34ac4482cd0c6a818bda89d78b30639316_prof);

        
        $__internal_a7f3e8ac6018550f8f078963fd38f28148f7d644293f0cc6cf1d475eca198101->leave($__internal_a7f3e8ac6018550f8f078963fd38f28148f7d644293f0cc6cf1d475eca198101_prof);

    }

    // line 9
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_7a35723a2a9a7d5bb3729ebc4e6614277a7daf1b62bbe654b33c834ae7f0e801 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7a35723a2a9a7d5bb3729ebc4e6614277a7daf1b62bbe654b33c834ae7f0e801->enter($__internal_7a35723a2a9a7d5bb3729ebc4e6614277a7daf1b62bbe654b33c834ae7f0e801_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_974537f73f37e9ff78b0889fa9ea092d3ec5b53c7707376510eb32d84eab814c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_974537f73f37e9ff78b0889fa9ea092d3ec5b53c7707376510eb32d84eab814c->enter($__internal_974537f73f37e9ff78b0889fa9ea092d3ec5b53c7707376510eb32d84eab814c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_974537f73f37e9ff78b0889fa9ea092d3ec5b53c7707376510eb32d84eab814c->leave($__internal_974537f73f37e9ff78b0889fa9ea092d3ec5b53c7707376510eb32d84eab814c_prof);

        
        $__internal_7a35723a2a9a7d5bb3729ebc4e6614277a7daf1b62bbe654b33c834ae7f0e801->leave($__internal_7a35723a2a9a7d5bb3729ebc4e6614277a7daf1b62bbe654b33c834ae7f0e801_prof);

    }

    // line 29
    public function block_body($context, array $blocks = array())
    {
        $__internal_03930cb0f7e65c4db9e837d34cecf67008ef9b76af2000d9f4642ad4d4ec713d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_03930cb0f7e65c4db9e837d34cecf67008ef9b76af2000d9f4642ad4d4ec713d->enter($__internal_03930cb0f7e65c4db9e837d34cecf67008ef9b76af2000d9f4642ad4d4ec713d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_4d3e3ba46b416b4646ee9c91164d7a8bee07aed68ed7baa8c796fbb279cac0b7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4d3e3ba46b416b4646ee9c91164d7a8bee07aed68ed7baa8c796fbb279cac0b7->enter($__internal_4d3e3ba46b416b4646ee9c91164d7a8bee07aed68ed7baa8c796fbb279cac0b7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_4d3e3ba46b416b4646ee9c91164d7a8bee07aed68ed7baa8c796fbb279cac0b7->leave($__internal_4d3e3ba46b416b4646ee9c91164d7a8bee07aed68ed7baa8c796fbb279cac0b7_prof);

        
        $__internal_03930cb0f7e65c4db9e837d34cecf67008ef9b76af2000d9f4642ad4d4ec713d->leave($__internal_03930cb0f7e65c4db9e837d34cecf67008ef9b76af2000d9f4642ad4d4ec713d_prof);

    }

    // line 42
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_6ebf324f4483ab9d8a613e99c0a0470dc204f5a223da5ca1fb709ff3f28d462a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6ebf324f4483ab9d8a613e99c0a0470dc204f5a223da5ca1fb709ff3f28d462a->enter($__internal_6ebf324f4483ab9d8a613e99c0a0470dc204f5a223da5ca1fb709ff3f28d462a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_a9b09ccb1848af55ab6ad2c3c25cf16c45ad5ed3378cbca79482b23ee24fc2e1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a9b09ccb1848af55ab6ad2c3c25cf16c45ad5ed3378cbca79482b23ee24fc2e1->enter($__internal_a9b09ccb1848af55ab6ad2c3c25cf16c45ad5ed3378cbca79482b23ee24fc2e1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_a9b09ccb1848af55ab6ad2c3c25cf16c45ad5ed3378cbca79482b23ee24fc2e1->leave($__internal_a9b09ccb1848af55ab6ad2c3c25cf16c45ad5ed3378cbca79482b23ee24fc2e1_prof);

        
        $__internal_6ebf324f4483ab9d8a613e99c0a0470dc204f5a223da5ca1fb709ff3f28d462a->leave($__internal_6ebf324f4483ab9d8a613e99c0a0470dc204f5a223da5ca1fb709ff3f28d462a_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  126 => 42,  109 => 29,  92 => 9,  79 => 43,  77 => 42,  63 => 30,  61 => 29,  40 => 10,  38 => 9,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html lang=\"en\">
  <head>
    <meta charset=\"utf-8\">
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, shrink-to-fit=no\">
    <meta name=\"description\" content=\"\">
    <meta name=\"author\" content=\"\">
    <link rel=\"icon\" href=\"../../favicon.ico\">
    {% block stylesheets %}{% endblock %}
    <title>Starter Template for Bootstrap</title>

    <!-- Bootstrap core CSS -->
    <link href=\"https://v4-alpha.getbootstrap.com/dist/css/bootstrap.min.css\" rel=\"stylesheet\">

    <!-- Custom styles for this template -->
    <link href=\"https://v4-alpha.getbootstrap.com/examples/starter-template/starter-template.css\" rel=\"stylesheet\">
  </head>

  <body>

    <nav class=\"navbar navbar-toggleable-md navbar-inverse bg-inverse fixed-top\">
      <button class=\"navbar-toggler navbar-toggler-right\" type=\"button\" data-toggle=\"collapse\" data-target=\"#navbarsExampleDefault\" aria-controls=\"navbarsExampleDefault\" aria-expanded=\"false\" aria-label=\"Toggle navigation\">
        <span class=\"navbar-toggler-icon\"></span>
      </button>
      <a class=\"navbar-brand\" href=\"#\">Navbar</a>
    </nav>

    <div class=\"container\">
        {% block body %}{% endblock %}
    </div><!-- /.container -->

    
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src=\"https://code.jquery.com/jquery-3.1.1.slim.min.js\" integrity=\"sha384-A7FZj7v+d/sdmMqp/nOQwliLvUsJfDHW+k9Omg/a/EheAdgtzNs3hpfag6Ed950n\" crossorigin=\"anonymous\"></script>
    <script>window.jQuery || document.write('<script src=\"../../assets/js/vendor/jquery.min.js\"><\\/script>')</script>
    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/tether/1.4.0/js/tether.min.js\" integrity=\"sha384-DztdAPBWPRXSA/3eYEEUWrWCy7G5KFbe8fFjk5JAIxUYHKkDx6Qin1DkWx51bBrb\" crossorigin=\"anonymous\"></script>
    <script src=\"https://v4-alpha.getbootstrap.com/dist/js/bootstrap.min.js\"></script>
    <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
    <script src=\"https://v4-alpha.getbootstrap.com/assets/js/ie10-viewport-bug-workaround.js\"></script>
    {% block javascripts %}{% endblock %}
  </body>
</html>

", "base.html.twig", "/var/www/html/Symfony.3.0.x/symfony_graph/app/Resources/views/base.html.twig");
    }
}
