<?php

/* default/index.html.twig */
class __TwigTemplate_dceb56a59c18c48718e8d29e4a25e98e5177db0f33ab183da65e3deae3ceaade extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "default/index.html.twig", 1);
        $this->blocks = array(
            'body' => array($this, 'block_body'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_28648de44f2bbbdb42ac607812567c890d883d0b0c7b59cefba4f670ed3957b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_28648de44f2bbbdb42ac607812567c890d883d0b0c7b59cefba4f670ed3957b9->enter($__internal_28648de44f2bbbdb42ac607812567c890d883d0b0c7b59cefba4f670ed3957b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $__internal_b062484fbcc7b04badbb39bfbb060190234c24ac391984bd1343fe2d50c4372a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_b062484fbcc7b04badbb39bfbb060190234c24ac391984bd1343fe2d50c4372a->enter($__internal_b062484fbcc7b04badbb39bfbb060190234c24ac391984bd1343fe2d50c4372a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "default/index.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_28648de44f2bbbdb42ac607812567c890d883d0b0c7b59cefba4f670ed3957b9->leave($__internal_28648de44f2bbbdb42ac607812567c890d883d0b0c7b59cefba4f670ed3957b9_prof);

        
        $__internal_b062484fbcc7b04badbb39bfbb060190234c24ac391984bd1343fe2d50c4372a->leave($__internal_b062484fbcc7b04badbb39bfbb060190234c24ac391984bd1343fe2d50c4372a_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_dc09a5aa30fbbf6ca8fb8f64a6dfaef95c6ff15c0c42d432ca5144f94e8a1198 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc09a5aa30fbbf6ca8fb8f64a6dfaef95c6ff15c0c42d432ca5144f94e8a1198->enter($__internal_dc09a5aa30fbbf6ca8fb8f64a6dfaef95c6ff15c0c42d432ca5144f94e8a1198_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_9101fc01c3828d3f699ac890e2f5ed0ea2bcd08ce2c4c1e5c14ee0e01c51d6fb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9101fc01c3828d3f699ac890e2f5ed0ea2bcd08ce2c4c1e5c14ee0e01c51d6fb->enter($__internal_9101fc01c3828d3f699ac890e2f5ed0ea2bcd08ce2c4c1e5c14ee0e01c51d6fb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "      <div class=\"starter-template\">
        <h1>Graph starter</h1>
        <!-- HTML -->
        <div id=\"chartdiv\"></div>
      </div>
";
        
        $__internal_9101fc01c3828d3f699ac890e2f5ed0ea2bcd08ce2c4c1e5c14ee0e01c51d6fb->leave($__internal_9101fc01c3828d3f699ac890e2f5ed0ea2bcd08ce2c4c1e5c14ee0e01c51d6fb_prof);

        
        $__internal_dc09a5aa30fbbf6ca8fb8f64a6dfaef95c6ff15c0c42d432ca5144f94e8a1198->leave($__internal_dc09a5aa30fbbf6ca8fb8f64a6dfaef95c6ff15c0c42d432ca5144f94e8a1198_prof);

    }

    // line 11
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_743c052110be8f18fc6e358e864aa16f955d5ef81167a54438059a5a80b52008 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_743c052110be8f18fc6e358e864aa16f955d5ef81167a54438059a5a80b52008->enter($__internal_743c052110be8f18fc6e358e864aa16f955d5ef81167a54438059a5a80b52008_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_bc21593baa19a7ebf2e1f4f565143684b005f7b7c07b2dda76463da839ab0101 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bc21593baa19a7ebf2e1f4f565143684b005f7b7c07b2dda76463da839ab0101->enter($__internal_bc21593baa19a7ebf2e1f4f565143684b005f7b7c07b2dda76463da839ab0101_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 12
        echo "<!-- Styles -->
<style>#chartdiv { width: 100%;height: 500px;}</style>
<!-- Resources css-->
<link rel=\"stylesheet\" href=\"https://www.amcharts.com/lib/3/plugins/export/export.css\" type=\"text/css\" media=\"all\" />
";
        
        $__internal_bc21593baa19a7ebf2e1f4f565143684b005f7b7c07b2dda76463da839ab0101->leave($__internal_bc21593baa19a7ebf2e1f4f565143684b005f7b7c07b2dda76463da839ab0101_prof);

        
        $__internal_743c052110be8f18fc6e358e864aa16f955d5ef81167a54438059a5a80b52008->leave($__internal_743c052110be8f18fc6e358e864aa16f955d5ef81167a54438059a5a80b52008_prof);

    }

    // line 19
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_824db10640ceb0c7092eaffc31105b69e7038f213c7f9f22dcc190519515273a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_824db10640ceb0c7092eaffc31105b69e7038f213c7f9f22dcc190519515273a->enter($__internal_824db10640ceb0c7092eaffc31105b69e7038f213c7f9f22dcc190519515273a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_61f1b6cdf7c01f90b892cc0259bce3e36140f84fad19ff7887ad6c58cfd6829f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_61f1b6cdf7c01f90b892cc0259bce3e36140f84fad19ff7887ad6c58cfd6829f->enter($__internal_61f1b6cdf7c01f90b892cc0259bce3e36140f84fad19ff7887ad6c58cfd6829f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 20
        echo "<!-- Jquery -->
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
<!-- Resources js-->
<script src=\"https://www.amcharts.com/lib/3/amcharts.js\"></script>
<script src=\"https://www.amcharts.com/lib/3/serial.js\"></script>
<script src=\"https://www.amcharts.com/lib/3/plugins/export/export.min.js\"></script>
<script src=\"https://www.amcharts.com/lib/3/themes/light.js\"></script>

<!-- Chart code -->
<script>

    \$.ajax({
        type: \"GET\",
        url: \"http://localhost:8000/show\",
        success: function (result) { 
            //var data = JSON.parse(result);
            console.log(result);

            var chart = AmCharts.makeChart(\"chartdiv\", {
                \"type\": \"serial\",
                \"theme\": \"light\",
                \"marginTop\":0,
                \"marginRight\": 80,
                \"dataProvider\": result,
                \"valueAxes\": [{
                    \"axisAlpha\": 0,
                    \"position\": \"left\"
                }],
                \"graphs\": [{
                    \"id\":\"g1\",
                    \"balloonText\": \"[[category]]<br><b><span style='font-size:14px;'>[[value]]</span></b>\",
                    \"bullet\": \"round\",
                    \"bulletSize\": 8,
                    \"lineColor\": \"#d1655d \",
                    \"lineThickness\": 2,
                    \"negativeLineColor\": \"#637bb6 \",
                    \"type\": \"smoothedLine\",
                    \"valueField\": \"value\"
                }],
                \"chartScrollbar\": {
                    \"graph\":\"g1\",
                    \"gridAlpha\":0,
                    \"color\":\"#888888 \",
                    \"scrollbarHeight\":55,
                    \"backgroundAlpha\":0,
                    \"selectedBackgroundAlpha\":0.1,
                    \"selectedBackgroundColor\":\"#888888 \",
                    \"graphFillAlpha\":0,
                    \"autoGridCount\":true,
                    \"selectedGraphFillAlpha\":0,
                    \"graphLineAlpha\":0.2,
                    \"graphLineColor\":\"#c2c2c2 \",
                    \"selectedGraphLineColor\":\"#888888 \",
                    \"selectedGraphLineAlpha\":1

            },\"chartCursor\": {
                    \"categoryBalloonDateFormat\": \"YYYY\",
                    \"cursorAlpha\": 0,
                    \"valueLineEnabled\":true,
                    \"valueLineBalloonEnabled\":true,
                    \"valueLineAlpha\":0.5,
                    \"fullWidth\":true
                },
                \"dataDateFormat\": \"YYYY\",
                \"categoryField\": \"year\",
                \"categoryAxis\": {
                    \"minPeriod\": \"YYYY\",
                    \"parseDates\": true,
                    \"minorGridAlpha\": 0.1,
                    \"minorGridEnabled\": true
                },
                \"export\": {
                    \"enabled\": true
                }
            });

            chart.addListener(\"rendered\", zoomChart);
            if(chart.zoomChart){
                chart.zoomChart();
            }

            function zoomChart(){
                chart.zoomToIndexes(Math.round(chart.dataProvider.length * 0.4), Math.round(chart.dataProvider.length * 0.55));
            }
        }
    });
</script>
";
        
        $__internal_61f1b6cdf7c01f90b892cc0259bce3e36140f84fad19ff7887ad6c58cfd6829f->leave($__internal_61f1b6cdf7c01f90b892cc0259bce3e36140f84fad19ff7887ad6c58cfd6829f_prof);

        
        $__internal_824db10640ceb0c7092eaffc31105b69e7038f213c7f9f22dcc190519515273a->leave($__internal_824db10640ceb0c7092eaffc31105b69e7038f213c7f9f22dcc190519515273a_prof);

    }

    public function getTemplateName()
    {
        return "default/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  98 => 20,  89 => 19,  75 => 12,  66 => 11,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'base.html.twig' %}

{% block body %}
      <div class=\"starter-template\">
        <h1>Graph starter</h1>
        <!-- HTML -->
        <div id=\"chartdiv\"></div>
      </div>
{% endblock %}

{% block stylesheets %}
<!-- Styles -->
<style>#chartdiv { width: 100%;height: 500px;}</style>
<!-- Resources css-->
<link rel=\"stylesheet\" href=\"https://www.amcharts.com/lib/3/plugins/export/export.css\" type=\"text/css\" media=\"all\" />
{% endblock %}


{% block javascripts %}
<!-- Jquery -->
<script src=\"https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js\"></script>
<!-- Resources js-->
<script src=\"https://www.amcharts.com/lib/3/amcharts.js\"></script>
<script src=\"https://www.amcharts.com/lib/3/serial.js\"></script>
<script src=\"https://www.amcharts.com/lib/3/plugins/export/export.min.js\"></script>
<script src=\"https://www.amcharts.com/lib/3/themes/light.js\"></script>

<!-- Chart code -->
<script>

    \$.ajax({
        type: \"GET\",
        url: \"http://localhost:8000/show\",
        success: function (result) { 
            //var data = JSON.parse(result);
            console.log(result);

            var chart = AmCharts.makeChart(\"chartdiv\", {
                \"type\": \"serial\",
                \"theme\": \"light\",
                \"marginTop\":0,
                \"marginRight\": 80,
                \"dataProvider\": result,
                \"valueAxes\": [{
                    \"axisAlpha\": 0,
                    \"position\": \"left\"
                }],
                \"graphs\": [{
                    \"id\":\"g1\",
                    \"balloonText\": \"[[category]]<br><b><span style='font-size:14px;'>[[value]]</span></b>\",
                    \"bullet\": \"round\",
                    \"bulletSize\": 8,
                    \"lineColor\": \"#d1655d \",
                    \"lineThickness\": 2,
                    \"negativeLineColor\": \"#637bb6 \",
                    \"type\": \"smoothedLine\",
                    \"valueField\": \"value\"
                }],
                \"chartScrollbar\": {
                    \"graph\":\"g1\",
                    \"gridAlpha\":0,
                    \"color\":\"#888888 \",
                    \"scrollbarHeight\":55,
                    \"backgroundAlpha\":0,
                    \"selectedBackgroundAlpha\":0.1,
                    \"selectedBackgroundColor\":\"#888888 \",
                    \"graphFillAlpha\":0,
                    \"autoGridCount\":true,
                    \"selectedGraphFillAlpha\":0,
                    \"graphLineAlpha\":0.2,
                    \"graphLineColor\":\"#c2c2c2 \",
                    \"selectedGraphLineColor\":\"#888888 \",
                    \"selectedGraphLineAlpha\":1

            },\"chartCursor\": {
                    \"categoryBalloonDateFormat\": \"YYYY\",
                    \"cursorAlpha\": 0,
                    \"valueLineEnabled\":true,
                    \"valueLineBalloonEnabled\":true,
                    \"valueLineAlpha\":0.5,
                    \"fullWidth\":true
                },
                \"dataDateFormat\": \"YYYY\",
                \"categoryField\": \"year\",
                \"categoryAxis\": {
                    \"minPeriod\": \"YYYY\",
                    \"parseDates\": true,
                    \"minorGridAlpha\": 0.1,
                    \"minorGridEnabled\": true
                },
                \"export\": {
                    \"enabled\": true
                }
            });

            chart.addListener(\"rendered\", zoomChart);
            if(chart.zoomChart){
                chart.zoomChart();
            }

            function zoomChart(){
                chart.zoomToIndexes(Math.round(chart.dataProvider.length * 0.4), Math.round(chart.dataProvider.length * 0.55));
            }
        }
    });
</script>
{% endblock %}
", "default/index.html.twig", "/var/www/html/Symfony.3.0.x/symfony_graph/app/Resources/views/default/index.html.twig");
    }
}
