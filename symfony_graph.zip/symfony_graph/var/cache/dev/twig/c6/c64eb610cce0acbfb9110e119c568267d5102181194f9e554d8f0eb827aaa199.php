<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_fc8d50b4ddaf604f422b05df6bd2514d63ecc83ac9533c9dcebb31515095dd1c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_84afa6df8ca02881fef98b75e41e2e1257a98ccd81bf5e1a4b2b0b028b5013fe = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_84afa6df8ca02881fef98b75e41e2e1257a98ccd81bf5e1a4b2b0b028b5013fe->enter($__internal_84afa6df8ca02881fef98b75e41e2e1257a98ccd81bf5e1a4b2b0b028b5013fe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_5624e3336da872c78a73fc6d4d99fc8dbea6f9da2aefa2dcae42a45bab545b33 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5624e3336da872c78a73fc6d4d99fc8dbea6f9da2aefa2dcae42a45bab545b33->enter($__internal_5624e3336da872c78a73fc6d4d99fc8dbea6f9da2aefa2dcae42a45bab545b33_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_84afa6df8ca02881fef98b75e41e2e1257a98ccd81bf5e1a4b2b0b028b5013fe->leave($__internal_84afa6df8ca02881fef98b75e41e2e1257a98ccd81bf5e1a4b2b0b028b5013fe_prof);

        
        $__internal_5624e3336da872c78a73fc6d4d99fc8dbea6f9da2aefa2dcae42a45bab545b33->leave($__internal_5624e3336da872c78a73fc6d4d99fc8dbea6f9da2aefa2dcae42a45bab545b33_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_dc34de7b1f5cef8e97ac0361d0ffe43fdd5eae676e4c6f9bba8dd6cb8efb12c6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dc34de7b1f5cef8e97ac0361d0ffe43fdd5eae676e4c6f9bba8dd6cb8efb12c6->enter($__internal_dc34de7b1f5cef8e97ac0361d0ffe43fdd5eae676e4c6f9bba8dd6cb8efb12c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_d6cdddf9d5982a0e6637453056e157808a65cb9ec5e2f4489cd6e84574f46bde = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d6cdddf9d5982a0e6637453056e157808a65cb9ec5e2f4489cd6e84574f46bde->enter($__internal_d6cdddf9d5982a0e6637453056e157808a65cb9ec5e2f4489cd6e84574f46bde_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_d6cdddf9d5982a0e6637453056e157808a65cb9ec5e2f4489cd6e84574f46bde->leave($__internal_d6cdddf9d5982a0e6637453056e157808a65cb9ec5e2f4489cd6e84574f46bde_prof);

        
        $__internal_dc34de7b1f5cef8e97ac0361d0ffe43fdd5eae676e4c6f9bba8dd6cb8efb12c6->leave($__internal_dc34de7b1f5cef8e97ac0361d0ffe43fdd5eae676e4c6f9bba8dd6cb8efb12c6_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_65b02d63cf4e0c8b955f764e10c28d4e5e5982e415ec3f4f84a754f4ee0fd087 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_65b02d63cf4e0c8b955f764e10c28d4e5e5982e415ec3f4f84a754f4ee0fd087->enter($__internal_65b02d63cf4e0c8b955f764e10c28d4e5e5982e415ec3f4f84a754f4ee0fd087_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_d4008e7b65c4c175892ad6dcd052ee71a84e7ea1111dc05360cb5da2fd16e84a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d4008e7b65c4c175892ad6dcd052ee71a84e7ea1111dc05360cb5da2fd16e84a->enter($__internal_d4008e7b65c4c175892ad6dcd052ee71a84e7ea1111dc05360cb5da2fd16e84a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_d4008e7b65c4c175892ad6dcd052ee71a84e7ea1111dc05360cb5da2fd16e84a->leave($__internal_d4008e7b65c4c175892ad6dcd052ee71a84e7ea1111dc05360cb5da2fd16e84a_prof);

        
        $__internal_65b02d63cf4e0c8b955f764e10c28d4e5e5982e415ec3f4f84a754f4ee0fd087->leave($__internal_65b02d63cf4e0c8b955f764e10c28d4e5e5982e415ec3f4f84a754f4ee0fd087_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_15d582d765a310084d5434499bf48c2fe8594d3a251f3cb65f80e11dbc1547c7 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_15d582d765a310084d5434499bf48c2fe8594d3a251f3cb65f80e11dbc1547c7->enter($__internal_15d582d765a310084d5434499bf48c2fe8594d3a251f3cb65f80e11dbc1547c7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_188f523aa8ea4bf076647d613520637dbfcb6c978de01252ddd705e08adfb63e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_188f523aa8ea4bf076647d613520637dbfcb6c978de01252ddd705e08adfb63e->enter($__internal_188f523aa8ea4bf076647d613520637dbfcb6c978de01252ddd705e08adfb63e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute((isset($context["collector"]) ? $context["collector"] : $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => (isset($context["token"]) ? $context["token"] : $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_188f523aa8ea4bf076647d613520637dbfcb6c978de01252ddd705e08adfb63e->leave($__internal_188f523aa8ea4bf076647d613520637dbfcb6c978de01252ddd705e08adfb63e_prof);

        
        $__internal_15d582d765a310084d5434499bf48c2fe8594d3a251f3cb65f80e11dbc1547c7->leave($__internal_15d582d765a310084d5434499bf48c2fe8594d3a251f3cb65f80e11dbc1547c7_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/var/www/html/Symfony.3.0.x/symfony_graph/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
